plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ehsan.spikecarremote"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ehsan.spikecarremote"
        minSdk = 23
        targetSdk = 30
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
